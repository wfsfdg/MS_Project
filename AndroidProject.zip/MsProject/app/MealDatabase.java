public class MealDatabase {
}
