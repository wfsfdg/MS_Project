package com.example.msproject;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBManager extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME="my.db";
    private static final int DATABASE_VERSION = 1;

    // 테이블 Meal
    private static final String TABLE_MEAL = "Meal";
    private static final String TABLE_DRINK="Drink";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_YEAR = "year";
    private static final String COLUMN_MONTH = "month";
    private static final String COLUMN_DAY = "day";
    private static final String COLUMN_HOUR = "hour";
    private static final String COLUMN_MINUTE = "minute";
    private static final String COLUMN_KCAL = "kcal";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_REVIEW = "review";
    private static final String COLUMN_IMAGE = "image";
    // 테이블 Food
    private static final String TABLE_FOOD = "Food";
    // ... (Food 테이블의 열 정의)

    public DBManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Meal 테이블 생성 쿼리
        String createMealTableQuery = "CREATE TABLE " + TABLE_MEAL + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT NOT NULL, " +
                COLUMN_YEAR + " INTEGER NOT NULL, " +
                COLUMN_MONTH + " INTEGER NOT NULL, " +
                COLUMN_DAY + " INTEGER NOT NULL, " +
                COLUMN_HOUR + " INTEGER NOT NULL, " +
                COLUMN_MINUTE + " INTEGER NOT NULL, " +
                COLUMN_KCAL + " INTEGER NOT NULL, " +
                COLUMN_PRICE + " INTEGER NOT NULL, " +
                COLUMN_REVIEW + " TEXT, " +
                COLUMN_IMAGE + " BLOB);";

        db.execSQL(createMealTableQuery);

        String createDrinkTableQuery = "CREATE TABLE " + TABLE_DRINK + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT NOT NULL, " +
                COLUMN_YEAR + " INTEGER NOT NULL, " +
                COLUMN_MONTH + " INTEGER NOT NULL, " +
                COLUMN_DAY + " INTEGER NOT NULL, " +
                COLUMN_HOUR + " INTEGER NOT NULL, " +
                COLUMN_MINUTE + " INTEGER NOT NULL, " +
                COLUMN_KCAL + " INTEGER NOT NULL, " +
                COLUMN_PRICE + " INTEGER NOT NULL, " +
                COLUMN_REVIEW + " TEXT, " +
                COLUMN_IMAGE + " BLOB);";

        db.execSQL(createMealTableQuery);

        //  테이블 생성 쿼리

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 업그레이드 로직이 필요할 경우 여기에 추가
    }

}
