package com.example.msproject;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.TextView;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class dataInput extends AppCompatActivity {
    private AutoCompleteTextView writemenu;
    private EditText writprice;
    List<String> searchList;
    AutoCompleteTextView autoCompleteTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datainput);
        EditText menu = findViewById(R.id.menu);
        String menuData = menu.getText().toString();
        EditText price = findViewById(R.id.price);
        String priceData = price.getText().toString();
        EditText review=findViewById(R.id.review);
        String reviewData=review.getText().toString();


        Intent getintent=getIntent();
        if (getintent!=null)
        {
            int selectedYear=getintent.getIntExtra("year",0);
            int selectedMonth=getintent.getIntExtra("month",0);
            int selectedDay=getintent.getIntExtra("dayOfMonth",0);
            int selectedHour=getintent.getIntExtra("hour",0);
            int selectedMinute=getintent.getIntExtra("minute",0);

            TextView textView=findViewById(R.id.dateTime);

            LocalDateTime selectedDateTime = LocalDateTime.of(selectedYear,selectedMonth+1,
                    selectedDay,selectedHour,selectedMinute);
            DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy년 M월 d일 HH:mm");
            String formattedDateTime=selectedDateTime.format(formatter);
            textView.setText(formattedDateTime);

        }

        {
            String selectedLoc = "";
            String selectedType = "";
            int defaultPosition = 0;
            Spinner spinner = findViewById(R.id.spinner);
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.locs,
                    android.R.layout.simple_spinner_item);//기본 스피너 레이아웃 사용
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            //스피너 선택화면 기본 레이아웃 사용
            spinner.setAdapter(adapter);
            spinner.setSelection(defaultPosition);


            Spinner spinner2 = findViewById(R.id.spinner2);
            ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.types,
                    android.R.layout.simple_spinner_item);//기본 스피너 레이아웃 사용
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            //스피너 선택화면 기본 레이아웃 사용
            spinner2.setAdapter(adapter2);
            spinner2.setSelection(defaultPosition);//1번째 항목을 디폴트로 설정
        }

        searchList = new ArrayList<>();

        // 자동완성 단어 리스트에 세팅
        settingList();

        autoCompleteTextView = findViewById(R.id.menu);

        autoCompleteTextView.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, searchList));

        writemenu=findViewById(R.id.menu);
        writprice=findViewById(R.id.price);
        writemenu.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    private void settingList()
    {
        searchList.add("철판돈가스");
        searchList.add("삼겹살김치철판");
        searchList.add("치즈불닭철판");
        searchList.add("데리야끼치킨솥밥");
        searchList.add("숯불삼겹솥밥");
        searchList.add("콘치즈솥밥");
        searchList.add("우삼겹솥밥");
        searchList.add("꼬치어묵우동");
        searchList.add("왕새우튀김우동");
        searchList.add("얼큰김치우동");
        searchList.add("우동*돈가스set");
        searchList.add("우동*알밥set");
        searchList.add("계란라면");
        searchList.add("치즈라면");
        searchList.add("해장라면");
        searchList.add("추억의도시락");
        searchList.add("공기밥");
        searchList.add("비비고찐만두");
        searchList.add("라볶이");
        searchList.add("떡순이");


    }
}