package com.example.msproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.Random;

public class DBManager extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME="my.db";
    private static final int DATABASE_VERSION = 1;
    private Context context;

    public DBManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }


    private static final String TABLE_MEAL = "Meal";
    private static final String TABLE_DRINK = "Drink";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_YEAR = "year";
    private static final String COLUMN_MONTH = "month";
    private static final String COLUMN_DAY = "day";
    private static final String COLUMN_HOUR = "hour";
    private static final String COLUMN_MINUTE = "minute";
    private static final String COLUMN_KCAL = "kcal";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_REVIEW = "review";
    private static final String COLUMN_IMAGE = "image";
    private static final String COLUMN_LOCATION="location";
    // 테이블 Food
    private static final String TABLE_FOOD = "Food";
    // ... (Food 테이블의 열 정의)



    @Override
    public void onCreate(SQLiteDatabase db) {
        // Meal 테이블 생성 쿼리
        String createMealTableQuery = "CREATE TABLE " + TABLE_MEAL + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT NOT NULL, " +
                COLUMN_YEAR + " INTEGER NOT NULL, " +
                COLUMN_MONTH + " INTEGER NOT NULL, " +
                COLUMN_DAY + " INTEGER NOT NULL, " +
                COLUMN_HOUR + " INTEGER NOT NULL, " +
                COLUMN_MINUTE + " INTEGER NOT NULL, " +
                COLUMN_LOCATION + "TEXT NOT NULL,"+
                COLUMN_KCAL + " INTEGER NOT NULL, " +
                COLUMN_PRICE + " TEXT NOT NULL, " +
                COLUMN_REVIEW + " TEXT, " +
                COLUMN_IMAGE + " BLOB);";

        db.execSQL(createMealTableQuery);

        String createDrinkTableQuery = "CREATE TABLE " + TABLE_DRINK + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT NOT NULL, " +
                COLUMN_YEAR + " INTEGER NOT NULL, " +
                COLUMN_MONTH + " INTEGER NOT NULL, " +
                COLUMN_DAY + " INTEGER NOT NULL, " +
                COLUMN_HOUR + " INTEGER NOT NULL, " +
                COLUMN_MINUTE + " INTEGER NOT NULL, " +
                COLUMN_LOCATION + "TEXT NOT NULL,"+
                COLUMN_KCAL + " INTEGER NOT NULL, " +
                COLUMN_PRICE + " TEXT NOT NULL, " +
                COLUMN_REVIEW + " TEXT, " +
                COLUMN_IMAGE + " BLOB);";

        db.execSQL(createDrinkTableQuery);

        //  테이블 생성 쿼리

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 업그레이드 로직이 필요할 경우 여기에 추가
    }
    public boolean isMealExists(String name, int year, int month, int day, int hour, int minute, String price) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_MEAL +
                " WHERE " + COLUMN_NAME + " = ? AND " +
                COLUMN_YEAR + " = ? AND " +
                COLUMN_MONTH + " = ? AND " +
                COLUMN_DAY + " = ? AND " +
                COLUMN_HOUR + " = ? AND " +
                COLUMN_MINUTE + " = ? AND " +
                COLUMN_PRICE + " = ?";

        Cursor cursor = db.rawQuery(query, new String[]{name, String.valueOf(year), String.valueOf(month), String.valueOf(day),
                String.valueOf(hour), String.valueOf(minute), String.valueOf(price)});
        boolean exists = cursor.getCount() > 0;

        cursor.close();
        db.close();

        return exists;
    }
    public boolean isDrinkExists(String name, int year, int month, int day, int hour, int minute, String price) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_DRINK +
                " WHERE " + COLUMN_NAME + " = ? AND " +
                COLUMN_YEAR + " = ? AND " +
                COLUMN_MONTH + " = ? AND " +
                COLUMN_DAY + " = ? AND " +
                COLUMN_HOUR + " = ? AND " +
                COLUMN_MINUTE + " = ? AND " +
                COLUMN_PRICE + " = ?";

        Cursor cursor = db.rawQuery(query, new String[]{name, String.valueOf(year), String.valueOf(month), String.valueOf(day),
                String.valueOf(hour), String.valueOf(minute), String.valueOf(price)});
        boolean exists = cursor.getCount() > 0;

        cursor.close();
        db.close();

        return exists;
    }
    public long insertMealData(String name, int year, int month, int day, int hour, int minute,
                               String location, String price, String review, byte[] image)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        if (isMealExists(name, year, month, day, hour, minute, price))
        {
            // 중복값 존재시
            Toast.makeText(context, "이미 존재하는 데이터입니다", Toast.LENGTH_SHORT).show();
            db.close();
            return -1; //메시지 전달 후 종료
        }
        else if ("".equals(name)||"".equals(price))
        {
            //메뉴나 가격을 입력하지 않았을 때
            Toast.makeText(context, "메뉴와 가격을 입력해주세요", Toast.LENGTH_SHORT).show();
            db.close();
            return -2;
        }


        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_YEAR, year);
        values.put(COLUMN_MONTH, month);
        values.put(COLUMN_DAY, day);
        values.put(COLUMN_HOUR, hour);
        values.put(COLUMN_MINUTE, minute);
        values.put(COLUMN_LOCATION,location);
        if ("철판돈가스".equals(name)) {values.put(COLUMN_KCAL, 600);}
        else  if ("삼겹살김치철판".equals(name)) {values.put(COLUMN_KCAL, 550);}
        else  if ("치즈불닭철판".equals(name)) {values.put(COLUMN_KCAL, 650);}
        else  if ("데리야끼치킨솥밥".equals(name)) {values.put(COLUMN_KCAL, 700);}
        else  if ("숯불삼겹솥밥".equals(name)) {values.put(COLUMN_KCAL, 450);}
        else  if ("콘치즈솥밥".equals(name)) {values.put(COLUMN_KCAL, 620);}
        else  if ("우삼겹솥밥".equals(name)) {values.put(COLUMN_KCAL, 610);}
        else  if ("꼬치어묵우동".equals(name)) {values.put(COLUMN_KCAL, 600);}
        else  if ("왕새우튀김우동".equals(name)) {values.put(COLUMN_KCAL, 590);}
        else  if ("얼큰김치우동".equals(name)) {values.put(COLUMN_KCAL, 580);}
        else  if ("우동*돈가스set".equals(name)) {values.put(COLUMN_KCAL,550);}
        else  if ("우동*알밥set".equals(name)) {values.put(COLUMN_KCAL, 540);}
        else  if ("계란라면".equals(name)) {values.put(COLUMN_KCAL, 630);}
        else  if ("치즈라면".equals(name)) {values.put(COLUMN_KCAL, 640);}
        else  if ("해장라면".equals(name)) {values.put(COLUMN_KCAL, 720);}
        else  if ("추억의도시락".equals(name)) {values.put(COLUMN_KCAL, 520);}
        else  if ("공기밥".equals(name)) {values.put(COLUMN_KCAL, 300);}
        else  if ("비비고찐만두".equals(name)) {values.put(COLUMN_KCAL, 400);}
        else  if ("라볶이".equals(name)) {values.put(COLUMN_KCAL, 600);}
        else  if ("떡순이".equals(name)) {values.put(COLUMN_KCAL, 600);}
        else {
            Random random= new Random();
            int randomKcal = random.nextInt(200) + 500; // 500~700사이의 랜덤값 입력
            values.put(COLUMN_KCAL, randomKcal);
        }
        values.put(COLUMN_PRICE, price);
        values.put(COLUMN_REVIEW, review);
        values.put(COLUMN_IMAGE, image);
        Toast.makeText(context, "저장 성공", Toast.LENGTH_SHORT).show();

        long newRowId = db.insert(TABLE_MEAL, null, values);

        db.close();

        return newRowId;
    }
    public long insertDrinkData(String name, int year, int month, int day, int hour, int minute, String location,
                                String price, String review, byte[] image) //테이블에 데이터 입력
    {
        SQLiteDatabase db = this.getWritableDatabase();
        if (isDrinkExists(name, year, month, day, hour, minute, price)) {
            // 중복값 존재시
            Toast.makeText(context, "이미 존재하는 데이터입니다.", Toast.LENGTH_SHORT).show();
            db.close();
            return -1; //메시지 전달 후 종료
        }
        else if ("".equals(name)||"".equals(price))
        {
            //메뉴나 가격을 입력하지 않았을 때
            Toast.makeText(context, "메뉴와 가격을 입력해주세요", Toast.LENGTH_SHORT).show();
            db.close();
            return -1;
        }
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_YEAR, year);
        values.put(COLUMN_MONTH, month);
        values.put(COLUMN_DAY, day);
        values.put(COLUMN_HOUR, hour);
        values.put(COLUMN_MINUTE, minute);
        values.put(COLUMN_LOCATION,location);
        Random random = new Random();
        int randomKcal = random.nextInt(200) + 300; // 300~500사이의 랜덤값 입력
        values.put(COLUMN_KCAL, randomKcal);
        values.put(COLUMN_PRICE, price);
        values.put(COLUMN_REVIEW, review);
        values.put(COLUMN_IMAGE, image);

        long newRowId = db.insert(TABLE_DRINK, null, values);
        Toast.makeText(context, "저장 성공", Toast.LENGTH_SHORT).show();

        db.close();

        return newRowId;
    }




}
